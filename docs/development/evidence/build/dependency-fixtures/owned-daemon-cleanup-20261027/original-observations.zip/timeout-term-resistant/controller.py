from pathlib import Path
import json,os,sys
sys.path.insert(0,'/root/projects/nativeCmpKit/scripts/dependencies')
import integrity as d
os.environ['JAVA_HOME']='/usr/lib/jvm/java-17-openjdk-amd64'
with d.sigterm_as_interrupt():
    result=d.run(Path('/dev/shm/nativecmpkit-owned-cleanup-suite-20261027-001/cases/timeout-term-resistant/project'),entry_root='.',run_id='bootstrap',mode='bootstrap',timeout=20,reserve_mib=8192,gradle_home=Path('/opt/gradle/gradle-9.7.1'),fresh_cache=True)
with Path('/dev/shm/nativecmpkit-owned-cleanup-suite-20261027-001/cases/timeout-term-resistant/controller-result.json').open('x') as stream:
    stream.write(json.dumps(result,indent=2,sort_keys=True)+'\n')
