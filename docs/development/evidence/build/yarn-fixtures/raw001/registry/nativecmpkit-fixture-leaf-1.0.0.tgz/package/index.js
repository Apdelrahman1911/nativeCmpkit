'use strict';
module.exports = 'inert synthetic fixture';
