'use strict';
require('fs').writeFileSync("dependency-script-ran.txt", 'self-authored harmless fixture marker\n', {flag: 'wx'});
