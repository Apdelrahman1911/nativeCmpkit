"""Source-held Python CI contract tests, not native executions."""
from pathlib import Path
import json, os, re, sys
ROOT=Path('/root/projects/nativeCmpKit'); OUT=Path(__file__).resolve().parent/'ci'
sys.path.insert(0,str(ROOT/'scripts/ci')); import library_tests as lt
assert not OUT.exists(); OUT.mkdir()
inputs=lt.snapshot_inputs(ROOT);lt.write_json(OUT/'inputs-before.json',inputs)
command=['/usr/bin/python3','-B','-m','unittest','discover','-s','scripts/ci','-p','test_*.py','-v']
env=os.environ.copy();env['TMPDIR']=str(OUT.parent);env['PYTHONDONTWRITEBYTECODE']='1'
execution=lt.execute(ROOT,command,OUT/'tests.log',180,8192,env=env)
after=lt.snapshot_inputs(ROOT);lt.write_json(OUT/'inputs-after.json',after)
s=(OUT/'tests.log').read_text();count=re.findall(r'^Ran (\d+) tests? in .+$',s,re.M)
passed=execution['exit_code']==0 and inputs==after and bool(re.search(r'^OK$',s,re.M)) and len(count)==1
lt.write_json(OUT/'receipt.json',{'recorded_utc':lt.utc_now(),'source_revision':lt.git_revision(ROOT), 'command':command,'execution':execution,'python_tooling_methods':int(count[0]) if len(count)==1 else None, 'passed':passed, 'source_inputs_held':inputs==after,'selected_input_count':len(inputs),'input_digest':lt.input_digest(inputs),'log_sha256':lt.sha256(OUT/'tests.log'),'driver_sha256':lt.sha256(Path(__file__)), 'library_native_packaged_consumer_methods_executed':0,'release_readiness_certified':False})
print((OUT/'receipt.json').read_text(),flush=True);sys.exit(0 if passed else 1)
